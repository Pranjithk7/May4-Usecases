package com.BusinessEntityJavaCollections.Main;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.BusinessEntityJavaCollections.Model.BusinessEntity;
import com.BusinessEntityJavaCollections.Model.MailingAddress;
import com.BusinessEntityJavaCollections.Model.RegisteredAddress;

public class Business {
	public static void main(String args[]){
		ArrayList<BusinessEntity> dataList=new ArrayList<BusinessEntity>();
		RegisteredAddress address=new RegisteredAddress("12 Queens Park","GB1024","Birmingham","United Kingdom");
		MailingAddress mail=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA" , "Hertfordshire", "United Kingdom");
		BusinessEntity data=new BusinessEntity((long) 999999990,"Tesco", address,mail,90,"GB");
		dataList.add(data);
		RegisteredAddress address1=new RegisteredAddress("Churchil Palace", "E14 5HP", "London", "United Kingdom");
		MailingAddress mail1=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessEntity data1=new BusinessEntity((long)999999991,"Barclays", address1,mail1,85,"GB");
		dataList.add(data1);
		RegisteredAddress address2=new RegisteredAddress("65 Lake Street", "06100", "Paris","France");
		MailingAddress mail2=new MailingAddress("Shire Park Kestrel Way", "AL7 1GA", "Hertfordshire", "United Kingdom");
		BusinessEntity data2=new BusinessEntity((long)888888880,"Soc Generale", address2,mail2,55,"FR");
		dataList.add(data2);
		
		Collections.sort(dataList,Comparator.comparingInt(BusinessEntity::getFailureScore).reversed());
		for(BusinessEntity businesstest:dataList){
			System.out.println("Business Identifier\t:"+businesstest.getBusinessIdentifier());
			System.out.println("Business Name\t:"+businesstest.getBusinessName());
			System.out.println("Registered Address\t:"+businesstest.getAddress());
			System.out.println("Mailing Address\t:"+businesstest.getMailingaddress());
			System.out.println("Failure Score\t:"+businesstest.getFailureScore());
			System.out.println("--------------Descending Order----------");
			
		}
	}

}
